import React from 'react'
import Header from '../../Components/Header/Header';
import HomeDocs from '../../Components/HomeDocs/HomeDocs';
import LatestBlogs from '../../Components/LatestBlogs/LatestBlogs';


const Demo = () => {
  return (
    <div>
      <LatestBlogs/>
    </div>
  )
}

export default Demo